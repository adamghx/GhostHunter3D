package mzw7af.cs2110.virginia.edu.ghosthunter_fridaythe13th;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

/**
 * Created by Maurice on 4/4/2015.
 */
public class GameActivity extends Activity {

    private ImageView character_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        setup();
    }

    public void setup() {
        RelativeLayout layout = (RelativeLayout) findViewById(R.id.gameLayout);
        character_image = (ImageView) findViewById(R.id.imageViewCharacter);
        layout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event){
//                Toast.makeText(MainActivity.this, "touched", Toast.LENGTH_SHORT).show();
                character_image.setX(event.getX());
                character_image.setY(event.getY());
                return true;
            }
        });

    }
}
